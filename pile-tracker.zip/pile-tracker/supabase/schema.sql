-- =====================================================================
-- Pile Tracker — Supabase schema
-- Run this in: Supabase Dashboard → SQL Editor → New query → Run
-- =====================================================================

-- ---------- 1. PROFILES (extends Supabase auth.users with a role) ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'site' check (role in ('site','qa','admin')),
  created_at timestamptz default now()
);

-- Auto-create a profile row whenever someone signs up
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, full_name, role)
  values (new.id, new.raw_user_meta_data->>'full_name', 'site');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ---------- 2. PROJECTS ----------
create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text,
  location text,
  contract_no text,
  created_at timestamptz default now()
);

-- ---------- 3. REGISTER ENTRIES (the design schedule, per job) ----------
create table if not exists register_entries (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  pile_ref text not null,
  dia numeric,
  grade numeric,
  vertical_reo text,
  vertical_reo_lower text,      -- lower 2m reo, may differ from top
  ligs text,
  socket numeric,
  cutoff_rl numeric,
  top_steel_rl numeric,
  grid_ref text,
  cancelled boolean default false,
  revision text,                 -- e.g. "Rev 26"
  created_at timestamptz default now(),
  unique (project_id, pile_ref)
);

-- ---------- 4. PILES (as-built records) ----------
create table if not exists piles (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  pile_ref text not null,

  -- as-built fields
  actual_dia numeric,
  actual_depth numeric,
  drill_date date,
  driller text,
  cage_status text,             -- 'Not installed' | 'Installed'
  pour_date date,
  concrete_vol numeric,
  concrete_docket text,
  delivered_grade text,
  qa_status text,                -- 'Pending' | 'Signed off'
  qa_inspector text,
  qa_notes text,

  created_by uuid references profiles(id),
  updated_at timestamptz default now(),
  created_at timestamptz default now(),
  unique (project_id, pile_ref)
);

-- ---------- 5. HOLD POINTS (drill / cage / pour, one row each) ----------
create table if not exists hold_points (
  id uuid primary key default gen_random_uuid(),
  pile_id uuid not null references piles(id) on delete cascade,
  hp_type text not null check (hp_type in ('drill','cage','pour')),
  released boolean default false,
  inspector text,
  hp_date date,
  photo_path text,               -- path inside the 'hold-point-photos' storage bucket
  created_at timestamptz default now(),
  unique (pile_id, hp_type)
);

-- ---------- 6. AUDIT LOG (who changed what, when) ----------
create table if not exists audit_log (
  id bigint generated always as identity primary key,
  table_name text not null,
  row_id uuid not null,
  action text not null,          -- insert/update/delete
  changed_by uuid references profiles(id),
  changed_at timestamptz default now(),
  diff jsonb
);

create or replace function audit_trigger() returns trigger as $$
begin
  insert into audit_log(table_name, row_id, action, changed_by, diff)
  values (
    TG_TABLE_NAME,
    coalesce(new.id, old.id),
    TG_OP,
    auth.uid(),
    case when TG_OP = 'DELETE' then to_jsonb(old) else to_jsonb(new) end
  );
  return coalesce(new, old);
end;
$$ language plpgsql security definer;

drop trigger if exists piles_audit on piles;
create trigger piles_audit after insert or update or delete on piles
  for each row execute procedure audit_trigger();

drop trigger if exists hp_audit on hold_points;
create trigger hp_audit after insert or update or delete on hold_points
  for each row execute procedure audit_trigger();

-- ---------- 7. ROW LEVEL SECURITY ----------
alter table profiles enable row level security;
alter table projects enable row level security;
alter table register_entries enable row level security;
alter table piles enable row level security;
alter table hold_points enable row level security;
alter table audit_log enable row level security;

-- Any logged-in user can read everything (single-company tool, simple model)
create policy "read all - profiles" on profiles for select using (auth.role() = 'authenticated');
create policy "read all - projects" on projects for select using (auth.role() = 'authenticated');
create policy "read all - register" on register_entries for select using (auth.role() = 'authenticated');
create policy "read all - piles" on piles for select using (auth.role() = 'authenticated');
create policy "read all - hp" on hold_points for select using (auth.role() = 'authenticated');
create policy "read all - audit" on audit_log for select using (auth.role() = 'authenticated');

-- Any logged-in user can log/update piles and hold points (site team on phones)
create policy "write piles" on piles for insert with check (auth.role() = 'authenticated');
create policy "update piles" on piles for update using (auth.role() = 'authenticated');
create policy "write hp" on hold_points for insert with check (auth.role() = 'authenticated');
create policy "update hp" on hold_points for update using (auth.role() = 'authenticated');

-- Only admin/qa can create projects or upload/replace the register
create policy "admin write projects" on projects for insert with check (
  exists (select 1 from profiles where id = auth.uid() and role in ('admin','qa'))
);
create policy "admin write register" on register_entries for insert with check (
  exists (select 1 from profiles where id = auth.uid() and role in ('admin','qa'))
);
create policy "admin update register" on register_entries for update using (
  exists (select 1 from profiles where id = auth.uid() and role in ('admin','qa'))
);
create policy "admin delete register" on register_entries for delete using (
  exists (select 1 from profiles where id = auth.uid() and role in ('admin','qa'))
);

-- Users can update their own profile; admin can update anyone's role
create policy "update own profile" on profiles for update using (auth.uid() = id);

-- ---------- 8. STORAGE BUCKET for hold-point photos ----------
insert into storage.buckets (id, name, public) values ('hold-point-photos', 'hold-point-photos', false)
on conflict (id) do nothing;

create policy "authenticated read photos" on storage.objects for select using (
  bucket_id = 'hold-point-photos' and auth.role() = 'authenticated'
);
create policy "authenticated upload photos" on storage.objects for insert with check (
  bucket_id = 'hold-point-photos' and auth.role() = 'authenticated'
);

-- =====================================================================
-- Done. Next: Authentication → Providers → enable Email.
-- Then create your first user (sign up in the app), then in the
-- Table editor set that user's row in `profiles` → role = 'admin'.
-- =====================================================================
