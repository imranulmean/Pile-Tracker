import { reconcileStatus } from "../lib/domain";

export default function Reconciliation({ register, piles }) {
  const pileByRef = new Map(piles.map((p) => [p.pile_ref, p]));
  const registerRefs = new Set(register.map((r) => r.pile_ref));

  const rows = register.map((r) => {
    const pile = pileByRef.get(r.pile_ref);
    const { status, diffs } = reconcileStatus(r, pile);
    return { pileRef: r.pile_ref, status, diffs };
  });

  // piles logged that aren't in the register at all
  for (const p of piles) {
    if (!registerRefs.has(p.pile_ref)) rows.push({ pileRef: p.pile_ref, status: "Not in register", diffs: [] });
  }

  const counts = rows.reduce((acc, r) => ((acc[r.status] = (acc[r.status] || 0) + 1), acc), {});

  return (
    <div className="page">
      <h2>Reconciliation</h2>
      <div className="counts">
        {Object.entries(counts).map(([status, n]) => (
          <span key={status} className={`count-pill ${status.replace(/\s/g, "-").toLowerCase()}`}>{status}: {n}</span>
        ))}
      </div>
      <table className="data-table">
        <thead><tr><th>Pile</th><th>Status</th><th>Differing fields</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.pileRef} className={r.status === "Mismatch" || r.status === "Not in register" ? "row-warn" : ""}>
              <td>{r.pileRef}</td>
              <td>{r.status}</td>
              <td>{r.diffs.join(", ")}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
