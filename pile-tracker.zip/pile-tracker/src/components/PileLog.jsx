import { useEffect, useState } from "react";
import { updatePile, upsertHoldPoint, uploadHoldPointPhoto, getPhotoUrl } from "../lib/api";
import { computeStage, stageMeta, flagsFor } from "../lib/domain";
import { useAuth } from "../lib/AuthContext";

function hpByType(pile) {
  const out = { drill: {}, cage: {}, pour: {} };
  (pile.hold_points || []).forEach((hp) => (out[hp.hp_type] = hp));
  return out;
}

function HoldPointCard({ label, hp, pileId, hpType, projectId, pileRef, onSaved, profile }) {
  const [busy, setBusy] = useState(false);
  const [photoUrl, setPhotoUrl] = useState(null);

  useEffect(() => {
    if (hp.photo_path) getPhotoUrl(hp.photo_path).then(setPhotoUrl);
  }, [hp.photo_path]);

  async function handlePhoto(file) {
    setBusy(true);
    try {
      const path = await uploadHoldPointPhoto(projectId, pileRef, hpType, file);
      const updated = await upsertHoldPoint(pileId, hpType, { photo_path: path });
      onSaved(updated);
    } finally {
      setBusy(false);
    }
  }

  async function release() {
    const updated = await upsertHoldPoint(pileId, hpType, {
      released: true,
      inspector: profile?.full_name || "",
      hp_date: new Date().toISOString().slice(0, 10),
    });
    onSaved(updated);
  }

  return (
    <div className={`hp-card ${hp.released ? "released" : ""}`}>
      <div className="hp-head">
        <strong>{label}</strong>
        <span className={`badge ${hp.released ? "good" : "pending"}`}>{hp.released ? "Released" : "Open"}</span>
      </div>
      {photoUrl ? (
        <img src={photoUrl} alt={label} className="hp-photo" />
      ) : (
        <div className="hp-photo placeholder">No photo</div>
      )}
      <div className="row-actions">
        <label className="button secondary as-label">
          {busy ? "Uploading…" : "Take / upload photo"}
          <input type="file" accept="image/*" capture="environment" hidden
            onChange={(e) => e.target.files[0] && handlePhoto(e.target.files[0])} />
        </label>
        {!hp.released && <button onClick={release}>Release hold point</button>}
      </div>
      {hp.inspector && <p className="muted small">By {hp.inspector} · {hp.hp_date}</p>}
    </div>
  );
}

export default function PileLog({ pile, registerEntry, projectId, onUpdated }) {
  const { profile } = useAuth();
  const [form, setForm] = useState(pile);
  const hp = hpByType(pile);
  const stage = computeStage(form);
  const flags = flagsFor(form, registerEntry, hp);

  useEffect(() => setForm(pile), [pile]);

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function save() {
    const updated = await updatePile(pile.id, {
      actual_dia: form.actual_dia || null,
      actual_depth: form.actual_depth || null,
      drill_date: form.drill_date || null,
      driller: form.driller || null,
      cage_status: form.cage_status || null,
      pour_date: form.pour_date || null,
      concrete_vol: form.concrete_vol || null,
      concrete_docket: form.concrete_docket || null,
      delivered_grade: form.delivered_grade || null,
      qa_status: form.qa_status || null,
      qa_inspector: form.qa_inspector || null,
      qa_notes: form.qa_notes || null,
    });
    onUpdated({ ...pile, ...updated });
  }

  function onHpSaved(updatedHp) {
    const newHps = (pile.hold_points || []).filter((h) => h.hp_type !== updatedHp.hp_type).concat(updatedHp);
    onUpdated({ ...pile, hold_points: newHps });
  }

  return (
    <div className="pile-log">
      <div className="page-head">
        <h2>Pile {pile.pile_ref}</h2>
        <span className="badge" style={{ background: stageMeta(stage).color }}>{stageMeta(stage).label}</span>
      </div>

      {registerEntry && (
        <p className="muted small">
          Spec: Ø{registerEntry.dia}mm · {registerEntry.grade}MPa · reo {registerEntry.vertical_reo}
          {registerEntry.vertical_reo_lower ? ` (lower ${registerEntry.vertical_reo_lower})` : ""} · ligs {registerEntry.ligs}
        </p>
      )}

      {flags.length > 0 && (
        <div className="flags">
          {flags.map((f, i) => <div key={i} className={`flag ${f.level}`}>{f.text}</div>)}
        </div>
      )}

      <div className="card">
        <h3>Drilling</h3>
        <div className="form-grid">
          <label>Actual dia (mm)<input type="number" value={form.actual_dia || ""} onChange={(e) => set("actual_dia", e.target.value)} /></label>
          <label>Drilled depth (m)<input type="number" value={form.actual_depth || ""} onChange={(e) => set("actual_depth", e.target.value)} /></label>
          <label>Drill date<input type="date" value={form.drill_date || ""} onChange={(e) => set("drill_date", e.target.value)} /></label>
          <label>Driller / rig<input value={form.driller || ""} onChange={(e) => set("driller", e.target.value)} /></label>
        </div>
      </div>

      <div className="card">
        <h3>Cage</h3>
        <label>Status
          <select value={form.cage_status || ""} onChange={(e) => set("cage_status", e.target.value)}>
            <option value="">Not installed</option>
            <option value="Installed">Installed</option>
          </select>
        </label>
      </div>

      <div className="card">
        <h3>Pour</h3>
        <div className="form-grid">
          <label>Pour date<input type="date" value={form.pour_date || ""} onChange={(e) => set("pour_date", e.target.value)} /></label>
          <label>Concrete volume (m³)<input type="number" value={form.concrete_vol || ""} onChange={(e) => set("concrete_vol", e.target.value)} /></label>
          <label>Docket no.<input value={form.concrete_docket || ""} onChange={(e) => set("concrete_docket", e.target.value)} /></label>
          <label>Delivered grade<input value={form.delivered_grade || ""} onChange={(e) => set("delivered_grade", e.target.value)} /></label>
        </div>
      </div>

      <div className="hp-grid">
        <HoldPointCard label="Pile drilled" hp={hp.drill} pileId={pile.id} hpType="drill" projectId={projectId} pileRef={pile.pile_ref} onSaved={onHpSaved} profile={profile} />
        <HoldPointCard label="Cage in ground (pre-pour)" hp={hp.cage} pileId={pile.id} hpType="cage" projectId={projectId} pileRef={pile.pile_ref} onSaved={onHpSaved} profile={profile} />
        <HoldPointCard label="Pile poured" hp={hp.pour} pileId={pile.id} hpType="pour" projectId={projectId} pileRef={pile.pile_ref} onSaved={onHpSaved} profile={profile} />
      </div>

      <div className="card">
        <h3>QA sign-off</h3>
        <div className="form-grid">
          <label>Status
            <select value={form.qa_status || ""} onChange={(e) => set("qa_status", e.target.value)}>
              <option value="">Pending</option>
              <option value="Signed off">Signed off</option>
            </select>
          </label>
          <label>Inspector<input value={form.qa_inspector || ""} onChange={(e) => set("qa_inspector", e.target.value)} /></label>
        </div>
        <label>Notes<textarea value={form.qa_notes || ""} onChange={(e) => set("qa_notes", e.target.value)} /></label>
      </div>

      <button onClick={save}>Save pile</button>
    </div>
  );
}
