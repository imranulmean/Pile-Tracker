import { useState } from "react";
import * as XLSX from "xlsx";
import { upsertRegisterRows } from "../lib/api";

// Maps your existing Excel column headers -> our database fields.
// Add alternate header spellings here as you encounter them in real schedules.
const COLUMN_MAP = {
  pile_ref: ["pile", "pile no", "pile ref", "no", "pile number"],
  dia: ["dia", "diameter", "dia (mm)"],
  grade: ["grade", "grade (mpa)", "concrete grade"],
  vertical_reo: ["vertical reo", "vert reo", "reo", "vertical reinforcement"],
  vertical_reo_lower: ["vertical reo lower", "lower 2m", "vert reo lower", "lower reo"],
  ligs: ["ligs", "ligatures"],
  socket: ["socket", "socket (m)"],
  cutoff_rl: ["cutoff rl", "cut off rl", "cutoff"],
  top_steel_rl: ["top steel rl", "top of steel rl", "top steel"],
  grid_ref: ["grid ref", "grid", "gridline"],
};

function normalizeHeader(h) {
  return (h || "").toString().trim().toLowerCase();
}

function mapRow(rawRow, headerIndex) {
  const out = { cancelled: false };
  for (const [field, aliases] of Object.entries(COLUMN_MAP)) {
    for (const alias of aliases) {
      if (headerIndex[alias] != null) {
        const val = rawRow[headerIndex[alias]];
        out[field] = val === undefined || val === "" ? null : val;
        break;
      }
    }
  }
  return out;
}

export default function ImportRegister({ projectId, onImported }) {
  const [preview, setPreview] = useState(null);
  const [revision, setRevision] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  function handleFile(file) {
    setError("");
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null });
        const headerRowIdx = rows.findIndex((r) => r.some((c) => normalizeHeader(c).includes("pile")));
        const headerRow = rows[headerRowIdx >= 0 ? headerRowIdx : 0].map(normalizeHeader);
        const headerIndex = {};
        headerRow.forEach((h, i) => (headerIndex[h] = i));

        const dataRows = rows.slice((headerRowIdx >= 0 ? headerRowIdx : 0) + 1);
        const mapped = dataRows
          .map((r) => mapRow(r, headerIndex))
          .filter((r) => r.pile_ref !== null && r.pile_ref !== undefined && r.pile_ref !== "");

        setPreview(mapped);
      } catch (err) {
        setError("Could not read that file. Make sure it's a .xlsx export of the register.");
      }
    };
    reader.readAsArrayBuffer(file);
  }

  async function confirmImport() {
    setBusy(true);
    setError("");
    try {
      await upsertRegisterRows(projectId, preview, revision || null);
      onImported?.();
      setPreview(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card">
      <h3>Update register from Excel</h3>
      <p className="muted small">
        Upload the latest schedule whenever there's a design change. Existing pile numbers are
        updated in place (by pile ref); new pile numbers are added. Nothing is logged as-built —
        this only updates the design schedule used for reconciliation.
      </p>
      <input
        type="file"
        accept=".xlsx,.xls,.csv"
        onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])}
      />
      <label className="inline">
        Revision label (optional)
        <input placeholder="e.g. Rev 27" value={revision} onChange={(e) => setRevision(e.target.value)} />
      </label>

      {error && <div className="error">{error}</div>}

      {preview && (
        <div>
          <p>{preview.length} pile rows found. Preview of first 5:</p>
          <table className="mini-table">
            <thead>
              <tr><th>Pile</th><th>Dia</th><th>Grade</th><th>Vert reo</th><th>Lower</th><th>Ligs</th></tr>
            </thead>
            <tbody>
              {preview.slice(0, 5).map((r, i) => (
                <tr key={i}>
                  <td>{r.pile_ref}</td><td>{r.dia}</td><td>{r.grade}</td>
                  <td>{r.vertical_reo}</td><td>{r.vertical_reo_lower}</td><td>{r.ligs}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="row-actions">
            <button onClick={confirmImport} disabled={busy}>{busy ? "Saving…" : `Confirm — save ${preview.length} rows`}</button>
            <button className="secondary" onClick={() => setPreview(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}
