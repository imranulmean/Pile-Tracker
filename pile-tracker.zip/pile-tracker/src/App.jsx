import { BrowserRouter, Routes, Route, Navigate, Link } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/AuthContext";
import { signOut } from "./lib/api";
import Login from "./pages/Login";
import Projects from "./pages/Projects";
import JobDashboard from "./pages/JobDashboard";
import "./styles.css";

function Shell({ children }) {
  const { profile, user } = useAuth();
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link to="/" className="brand">NCF Pile Tracker</Link>
        <div className="who">
          <span>{profile?.full_name || user?.email} ({profile?.role})</span>
          <button className="link" onClick={signOut}>Sign out</button>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}

function Private({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="page">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  return <Shell>{children}</Shell>;
}

function Routed() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Private><Projects /></Private>} />
      <Route path="/jobs/:id" element={<Private><JobDashboard /></Private>} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routed />
      </BrowserRouter>
    </AuthProvider>
  );
}
