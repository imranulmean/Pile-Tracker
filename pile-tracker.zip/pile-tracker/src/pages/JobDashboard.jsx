import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { listRegister, listPiles, getOrCreatePile, pilesToCsv, downloadCsv } from "../lib/api";
import { computeStage, stageMeta } from "../lib/domain";
import { useAuth } from "../lib/AuthContext";
import ImportRegister from "../components/ImportRegister";
import PileLog from "../components/PileLog";
import Reconciliation from "../components/Reconciliation";

export default function JobDashboard() {
  const { id: projectId } = useParams();
  const { profile, user } = useAuth();
  const [tab, setTab] = useState("piles");
  const [register, setRegister] = useState([]);
  const [piles, setPiles] = useState([]);
  const [activePile, setActivePile] = useState(null);
  const [newPileRef, setNewPileRef] = useState("");
  const isAdmin = profile?.role === "admin" || profile?.role === "qa";

  async function refresh() {
    const [r, p] = await Promise.all([listRegister(projectId), listPiles(projectId)]);
    setRegister(r);
    setPiles(p);
  }
  useEffect(() => { refresh(); }, [projectId]);

  async function openPile(ref) {
    const pile = await getOrCreatePile(projectId, ref, user.id);
    setActivePile(pile);
  }

  function onPileUpdated(updated) {
    setPiles((prev) => {
      const others = prev.filter((p) => p.id !== updated.id);
      return [...others, updated].sort((a, b) => a.pile_ref.localeCompare(b.pile_ref, undefined, { numeric: true }));
    });
    setActivePile(updated);
  }

  const registerByRef = new Map(register.map((r) => [r.pile_ref, r]));

  if (activePile) {
    return (
      <div className="page">
        <button className="link" onClick={() => setActivePile(null)}>&larr; Back to job</button>
        <PileLog
          pile={activePile}
          registerEntry={registerByRef.get(activePile.pile_ref)}
          projectId={projectId}
          onUpdated={onPileUpdated}
        />
      </div>
    );
  }

  return (
    <div className="page">
      <div className="tabs">
        <button className={tab === "piles" ? "active" : ""} onClick={() => setTab("piles")}>Piles</button>
        <button className={tab === "register" ? "active" : ""} onClick={() => setTab("register")}>Register</button>
        <button className={tab === "recon" ? "active" : ""} onClick={() => setTab("recon")}>Reconciliation</button>
      </div>

      {tab === "register" && (
        <div>
          {isAdmin && <ImportRegister projectId={projectId} onImported={refresh} />}
          <table className="data-table">
            <thead><tr><th>Pile</th><th>Dia</th><th>Grade</th><th>Vert reo</th><th>Lower</th><th>Ligs</th><th>Rev</th></tr></thead>
            <tbody>
              {register.map((r) => (
                <tr key={r.id} className={r.cancelled ? "row-cancelled" : ""}>
                  <td>{r.pile_ref}</td><td>{r.dia}</td><td>{r.grade}</td>
                  <td>{r.vertical_reo}</td><td>{r.vertical_reo_lower}</td><td>{r.ligs}</td><td>{r.revision}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "recon" && <Reconciliation register={register} piles={piles} />}

      {tab === "piles" && (
        <div>
          <div className="page-head">
            <form className="inline-form" onSubmit={(e) => { e.preventDefault(); newPileRef && openPile(newPileRef); }}>
              <input placeholder="Pile ref (e.g. 245)" value={newPileRef} onChange={(e) => setNewPileRef(e.target.value)} />
              <button type="submit">Log pile</button>
            </form>
            <button className="secondary" onClick={() => downloadCsv(`piles-${projectId}.csv`, pilesToCsv(piles))}>
              Export CSV
            </button>
          </div>
          <table className="data-table">
            <thead><tr><th>Pile</th><th>Stage</th><th>Drill date</th><th>Pour date</th><th>QA</th></tr></thead>
            <tbody>
              {piles.map((p) => {
                const stage = computeStage(p);
                return (
                  <tr key={p.id} className="clickable" onClick={() => openPile(p.pile_ref)}>
                    <td>{p.pile_ref}</td>
                    <td><span className="badge" style={{ background: stageMeta(stage).color }}>{stageMeta(stage).label}</span></td>
                    <td>{p.drill_date || "—"}</td>
                    <td>{p.pour_date || "—"}</td>
                    <td>{p.qa_status || "Pending"}</td>
                  </tr>
                );
              })}
              {piles.length === 0 && <tr><td colSpan={5} className="muted">No piles logged yet. Type a pile number above to start.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
