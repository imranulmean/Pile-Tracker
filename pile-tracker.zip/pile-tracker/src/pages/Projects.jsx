import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { listProjects, createProject } from "../lib/api";
import { useAuth } from "../lib/AuthContext";

export default function Projects() {
  const { profile } = useAuth();
  const [projects, setProjects] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({ name: "", code: "", location: "", contract_no: "" });
  const nav = useNavigate();
  const canCreate = profile?.role === "admin" || profile?.role === "qa";

  useEffect(() => {
    listProjects().then(setProjects);
  }, []);

  async function submit(e) {
    e.preventDefault();
    const p = await createProject(form);
    setProjects([p, ...projects]);
    setShowNew(false);
    setForm({ name: "", code: "", location: "", contract_no: "" });
  }

  return (
    <div className="page">
      <div className="page-head">
        <h2>Jobs</h2>
        {canCreate && <button onClick={() => setShowNew((v) => !v)}>{showNew ? "Cancel" : "+ New job"}</button>}
      </div>

      {showNew && (
        <form className="card" onSubmit={submit}>
          <label>Name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
          <label>Code<input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} /></label>
          <label>Location<input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></label>
          <label>Contract / project no.<input value={form.contract_no} onChange={(e) => setForm({ ...form, contract_no: e.target.value })} /></label>
          <button type="submit">Create job</button>
        </form>
      )}

      <div className="grid">
        {projects.map((p) => (
          <div key={p.id} className="card clickable" onClick={() => nav(`/jobs/${p.id}`)}>
            <h3>{p.name}</h3>
            <p className="muted">{p.code} · {p.location}</p>
            <p className="muted small">Contract {p.contract_no || "—"}</p>
          </div>
        ))}
        {projects.length === 0 && <p className="muted">No jobs yet.</p>}
      </div>
    </div>
  );
}
