import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["logo.png"],
      manifest: {
        name: "NCF Pile Tracker",
        short_name: "PileTracker",
        description: "Bored pile QA tracking and ITP reporting",
        theme_color: "#1f2937",
        background_color: "#0b0d10",
        display: "standalone",
        start_url: "/",
        icons: [
          { src: "logo.png", sizes: "192x192", type: "image/png" },
          { src: "logo.png", sizes: "512x512", type: "image/png" }
        ]
      },
      workbox: {
        // Cache the app shell so it opens with no signal.
        // NOTE: data writes still need a connection (see OFFLINE_QUEUE.md).
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/.*\.supabase\.co\/storage\/.*/,
            handler: "CacheFirst",
            options: { cacheName: "photo-cache", expiration: { maxEntries: 500 } }
          }
        ]
      }
    })
  ],
  server: { host: true, port: 5173 }
});
