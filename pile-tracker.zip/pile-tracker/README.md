# NCF Pile Tracker — real codebase

This replaces the prototype's `localStorage` with a real Supabase backend:
shared multi-user data, logins with roles, photo upload to cloud storage,
and an installable PWA (works on iPhone/Android home screen, including
offline app-shell caching).

## What you get out of the box

- **Auth**: email/password login, roles (`site`, `qa`, `admin`)
- **Projects / jobs**
- **Register import**: upload an Excel file any time a design changes — this is
  answers your "how do I update the register as Admin" question directly
  (Register tab → Update register from Excel). Existing pile numbers are
  updated by pile ref; new ones are added.
- **Pile logging**: drill / cage / pour fields, automatic stage progression
- **3 hold points** per pile, each with photo capture straight from the phone
  camera (`capture="environment"`), uploaded to Supabase Storage
- **QA flags**: Ø/grade mismatch, under-pour/overbreak, poured-before-cage,
  missing photos — same rules as your prototype
- **Reconciliation**: register vs logged piles
- **CSV export**
- **Audit log**: every pile/hold-point change is recorded with who + when
  (`audit_log` table)

## What's intentionally NOT done yet (see "Next" below)

- ITP PDF sheet / printable checklist (the prototype's print view — straightforward
  to port, kept out of this pass to get you live faster)
- True offline write queue (right now: app shell + cached photos work offline,
  but saving a pile needs a connection — see "Offline" below)
- Native iOS/Android wrapper — this ships as an installable PWA instead

## 1. Create your Supabase project (5 min)

1. Go to https://supabase.com → New project (pick the **Sydney** region for
   Australian data residency)
2. Once it's ready: **SQL Editor** → paste the contents of `supabase/schema.sql`
   → Run
3. **Authentication → Providers** → make sure **Email** is enabled
4. **Project Settings → API** → copy the **Project URL** and **anon public key**

## 2. Configure the app

```bash
cp .env.example .env
# paste your URL + anon key into .env
```

## 3. Run it locally

```bash
npm install
npm run dev
```

Open the printed localhost URL. Sign up with your own email — this creates
your user with role `site` by default.

## 4. Make yourself admin

Supabase Dashboard → **Table editor** → `profiles` table → find your row →
set `role` to `admin`. Now you can create jobs and import the register.

## 5. Try it end to end

1. Sign in → **+ New job** → fill in name/code/contract no.
2. Open the job → **Register** tab → **Update register from Excel** → upload
   one of your real schedules
3. **Piles** tab → type a pile number → **Log pile** → fill in drill info,
   take a hold-point photo (works great on a phone), release the hold point
4. **Reconciliation** tab → see Matched/Mismatch/Not logged status

## 6. Deploy it so the team can use it from their phones

Cheapest/easiest: **Vercel** or **Netlify** (free tier covers this easily).

```bash
npm run build
```
Then either:
- drag the `dist/` folder into Netlify's deploy page, or
- `npx vercel` from this folder and follow the prompts

Set the same two env vars (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) in
the hosting platform's dashboard before building.

**On Hostinger specifically**: Hostinger shared hosting can serve the built
`dist/` folder (it's just static files) — upload its contents via their file
manager or FTP. The backend (Supabase) is hosted separately on Supabase's own
servers regardless of where you serve the frontend from.

## 7. Install on phones

Open the deployed URL in Safari (iPhone) or Chrome (Android) → **Add to Home
Screen**. It now behaves like an installed app, with the app shell and any
viewed photos cached for offline viewing.

## Costs

- Supabase free tier: 500MB database, 1GB storage, 50k monthly active users —
  enough to start. Paid tier starts at $25/month when you outgrow it
  (thousands of piles + photos will get you there — budget for it)
- Hosting (Vercel/Netlify/Hostinger static): free–$5/month

## Data ownership / backups / exit

- You own the Supabase project outright (your account, your billing)
- Supabase does daily backups on paid tiers; on free tier, export manually:
  Table editor → each table → Export CSV, or `pg_dump` via the connection
  string in Project Settings → Database
- Photos: Storage → bucket → can be bulk-downloaded via the Supabase CLI
- No vendor lock-in beyond Supabase itself being Postgres + S3-compatible
  storage — both are portable to any other Postgres host if you ever migrate

## Offline (important limitation to know)

Right now, **logging a pile or hold point requires a connection**. The PWA
caches the app shell and viewed photos so the app *opens* with no signal, but
writes don't queue yet. For true offline logging (queue writes locally, sync
when back in range), the next step is adding a local queue — ask me to build
this once the MVP above is confirmed working on real jobs.

## Next steps (recommended order)

1. Confirm the MVP above works against your two real registers
2. Add the ITP print sheet (one A4 per pile) + condensed checklist with your logo
3. Add the offline write queue for genuinely poor-signal sites
4. Add capping beam / walls / excavation / carting as new "work type" tables
   once piling is solid — same pattern (register + as-built + hold points)
   extends cleanly to those
